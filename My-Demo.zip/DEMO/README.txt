
Narok North Bursary & Projects - Offline Demo
============================================

What this contains:
- /public -> public site (Home, Apply, Projects, News, About, Contact)
- /admin/mp -> MP dashboard (MP can view all applications and approve/reject)
- /admin/ward -> Ward admin dashboard (ward-specific view; demo ward = Olopito Ward)

Demo logins (for demonstration only; offline demo uses browser localStorage):
- MP dashboard: open admin/mp/index.html from the ZIP
  (Demo note: no server-side login; use built-in demo buttons)
- Ward dashboard: open admin/ward/index.html from the ZIP

How to demo to the MP:
1. Open public/index.html in a browser (drag-and-drop from extracted folder)
2. Go to Apply for Bursary -> submit a tertiary and secondary application (they save to browser localStorage)
3. Open admin/ward/index.html (Ward admin) and click 'Load My Ward Applications' to show ward-only apps (demo ward = Olopito Ward)
4. Open admin/mp/index.html and click 'Load Applications' to see all apps and approve/reject (changes saved in localStorage)

Note: For a real production deployment, this offline demo should be replaced with server-side backend and database.
