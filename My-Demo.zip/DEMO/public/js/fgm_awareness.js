// fgm_awareness.js
// This file provides interactive features and information for FGM Awareness page.

// Section data
const fgmSections = [
  {
    title: "Report",
    content: `
      <p>You can report FGM cases through chiefs, police hotlines, local leaders, or child protection centers.</p>
      <form id="fgm-report-form">
        <label for="reporterName">Your Name:</label><br>
        <input type="text" id="reporterName" name="reporterName" required><br>
        <label for="contact">Contact Info:</label><br>
        <input type="text" id="contact" name="contact" required><br>
        <label for="location">Location:</label><br>
        <input type="text" id="location" name="location" required><br>
        <label for="details">Details of Incident:</label><br>
        <textarea id="details" name="details" rows="3" required></textarea><br>
        <button type="submit">Submit Report</button>
      </form>
      <div id="report-success" style="display:none;color:green;margin-top:10px;">Report submitted. Thank you for helping protect the community.</div>
    `
  },
  {
    title: "Authorities & Contacts",
    content: `
      <ul>
        <li>Police Hotline: 999</li>
        <li>Childline Kenya: 116</li>
        <li>Chief's Office: Local administration</li>
      </ul>
    `
  },
  {
    title: "What Happens After Reporting",
    content: `
      <p>The case is investigated, the survivor receives protection, and authorities take legal action against perpetrators.</p>
    `
  },
  {
    title: "Community Awareness",
    content: `
      <p>Community programs raise awareness about the dangers of FGM and promote alternative rites of passage.</p>
    `
  },
  {
    title: "Emergency Support",
    content: `
      <p>Survivors can receive medical treatment, psychosocial support, and temporary safe shelter.</p>
    `
  }
];

// Render sections
function renderFGMSections(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = fgmSections.map(section => `
    <h2>${section.title}</h2>
    ${section.content}
  `).join('');

  // Add form handler for report
  const form = document.getElementById('fgm-report-form');
  if (form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      // Collect form data
      const report = {
        name: form.reporterName.value,
        contact: form.contact.value,
        location: form.location.value,
        details: form.details.value,
        timestamp: new Date().toISOString()
      };
      // Save to localStorage for MP dashboard
      const reports = JSON.parse(localStorage.getItem('fgmReports') || '[]');
      reports.push(report);
      localStorage.setItem('fgmReports', JSON.stringify(reports));
      // Show success message
      form.style.display = 'none';
      document.getElementById('report-success').style.display = 'block';
    });
  }
}

// On DOM ready, render into .container
window.addEventListener('DOMContentLoaded', function() {
  renderFGMSections('fgm-awareness-container');
});
