
// apply.js - localStorage based application saving
const wards = ['Olopito Ward','Olokurto Ward','Enaibelibel Ward','Topoti Ward','Olorropil Ward'];
const institutions = ['Narok Technical Institute','Narok Teachers College','Narok University','Local TVET','Other'];

function fillSelects(){
  const w1 = document.getElementById('ward-select-ter');
  const w2 = document.getElementById('ward-select-sec');
  wards.forEach(w=>{
    const o1=document.createElement('option');o1.value=w;o1.text=w;w1.appendChild(o1);
    const o2=document.createElement('option');o2.value=w;o2.text=w;w2.appendChild(o2);
  });
  const i1 = document.getElementById('inst-select-ter');
  const i2 = document.getElementById('inst-select-sec');
  institutions.forEach(i=>{const o=document.createElement('option');o.value=i;o.text=i;i1.appendChild(o);i2.appendChild(o.cloneNode(true));});
}

function saveApp(form, type){
  const fd = new FormData(form);
  const obj = {};
  for(const [k,v] of fd.entries()) obj[k]=v;
  obj.type = type;
  obj.id = Date.now().toString(36);
  // Ensure ward is present for secondary
  if(type==='secondary' && !obj.ward) obj.ward = '';
  let apps = JSON.parse(localStorage.getItem('apps')||'[]');
  apps.push(obj);
  localStorage.setItem('apps', JSON.stringify(apps));
  alert('Application submitted (demo). Your application ID: '+obj.id);
}

document.addEventListener('DOMContentLoaded', ()=>{
  fillSelects();
  const tf = document.getElementById('tertiary-form');
  const sf = document.getElementById('secondary-form');
  tf.addEventListener('submit',(e)=>{e.preventDefault();saveApp(tf,'tertiary');tf.reset();});
  sf.addEventListener('submit',(e)=>{e.preventDefault();saveApp(sf,'secondary');sf.reset();});
  document.getElementById('tertiary-edit').addEventListener('click',()=>{
    const nid = prompt('Enter your National ID to edit your latest tertiary application:');
    if(!nid) return;
    const apps = JSON.parse(localStorage.getItem('apps')||'[]').filter(a=>a.type==='tertiary' && a.nid===nid);
    if(apps.length===0){alert('No tertiary application found for that ID.');return;}
    const last = apps[apps.length-1];
    // prefill form
    tf.first.value = last.first || '';
    tf.second.value = last.second || '';
    tf.last.value = last.last || '';
    tf.nid.value = last.nid || '';
    tf.ward.value = last.ward || '';
    tf.institution.value = last.institution || '';
    tf.email.value = last.email || '';
    tf.phone.value = last.phone || '';
    // allow overwrite by deleting previous and saving new when submit
    const appsAll = JSON.parse(localStorage.getItem('apps')||'[]').filter(a=>a.id!==last.id);
    localStorage.setItem('apps', JSON.stringify(appsAll));
    alert('You can now edit and resubmit the form. Previous submission removed.');
  });
});
