
// news.js - render news grid with 5 items and horizontal scroll
const sampleNews = [
  {title:'County Budget Released',excerpt:'Narok county budget highlights for 2025/26. Major allocations to education, health, and infrastructure.',img:'assets/news1.jpg',category:'Narok County News'},
  {title:'Constituency Outreach',excerpt:'Community meeting updates: MP meets with local leaders to discuss development.',img:'assets/news2.jpg',category:'Constituency Updates'},
  {title:'FGM Awareness Drive',excerpt:'New campaign launched to end FGM in Narok North. Community sensitization ongoing.',img:'assets/news3.jpg',category:'Awareness'},
  {title:'School Renovations',excerpt:'Renovation works begin in Enaibelibel and Olopito schools. Improved learning environment expected.',img:'assets/news4.jpg',category:'Education'},
  {title:'Water Project Completed',excerpt:'Olopito Borehole now operational, providing clean water to hundreds of residents.',img:'assets/news5.jpg',category:'Projects'}
];
function renderNews(){
  const g=document.getElementById('news-grid');
  g.innerHTML = '';
  sampleNews.forEach(n=>{
    const c=document.createElement('div');
    c.className='card news-card';
    c.innerHTML=`
      <div class="news-img-wrap"><img src="${n.img}" alt=""/></div>
      <div class="news-content">
        <span class="news-category">${n.category}</span>
        <h4>${n.title}</h4>
        <p class='small'>${n.excerpt}</p>
      </div>
    `;
    g.appendChild(c);
  });
}
document.addEventListener('DOMContentLoaded',renderNews);
