
// public.js - populates demo news slider
const sampleNews = [
  {title:'Bursary Application Window Open', excerpt:'Applications for 2026 open for all eligible students.', img:'assets/news1.jpg', category:'Constituency'},
  {title:'New Water Project Completed', excerpt:'A new borehole completed in Olopito ward.', img:'assets/news2.jpg', category:'Projects'},
  {title:'MP Meets Youth', excerpt:'Discussion on education and job creation.', img:'assets/news3.jpg', category:'Political'}
];

function buildNews(){
  const container = document.getElementById('news-slider');
  sampleNews.forEach(n=>{
    const el = document.createElement('div');
    el.className='card';
    el.innerHTML = `<img style="width:100%;height:140px;object-fit:cover;border-radius:6px" src="${n.img}" alt=""><h4>${n.title}</h4><p class="small">${n.excerpt}</p>`;
    container.appendChild(el);
  });
}
document.addEventListener('DOMContentLoaded', ()=>{buildNews();});
