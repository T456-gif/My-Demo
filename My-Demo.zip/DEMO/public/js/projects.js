
// projects.js - demo projects render and filter
const sampleProjects = [
  {id:1,title:'Olopito Borehole',ward:'Olopito Ward',status:'completed',img:'assets/proj1.jpg',desc:'Borehole providing water.'},
  {id:2,title:'Topoti Road Upgrade',ward:'Topoti Ward',status:'ongoing',img:'assets/proj2.jpg',desc:'Road rehabilitation.'},
  {id:3,title:'Enaibelibel School Renovation',ward:'Enaibelibel Ward',status:'stalled',img:'assets/proj3.jpg',desc:'Renovation paused.'}
  ];
function renderProjects(list){
  const grid = document.getElementById('projects-grid');
  grid.innerHTML='';
  list.forEach(p=>{
      const d = document.createElement('div'); d.className='project-card';
      let statusClass = 'project-status';
      if (p.status === 'ongoing') statusClass += ' inprogress';
      if (p.status === 'stalled') statusClass += ' stalled';
      d.innerHTML = `
        <img class="project-img" src="${p.img}" alt="${p.title}">
        <span class="project-title">${p.title}</span>
        <span class="${statusClass}">${p.status.charAt(0).toUpperCase()+p.status.slice(1)}</span>
        <p class="small"><strong>Ward:</strong> ${p.ward}</p>
        <p class="small">${p.desc}</p>
      `;
    grid.appendChild(d);
  });
}
function filterProj(s){ if(s==='all') renderProjects(sampleProjects); else renderProjects(sampleProjects.filter(p=>p.status===s)); }
document.addEventListener('DOMContentLoaded',()=>filterProj('all'));
// Sync projects to localStorage for MP dashboard
window.localStorage.setItem('projects', JSON.stringify(sampleProjects));
