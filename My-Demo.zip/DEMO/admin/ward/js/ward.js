
// Ward list and mapping
const WARD_LIST = [
  'Olopito Ward',
  'Olokurto Ward',
  'Enaibelibel Ward',
  'Topoti Ward',
  'Olorropil Ward'
];
let WARD_NAME = '';

function setWardNameFromStorage() {
  const wardNum = localStorage.getItem('wardNum');
  if (!wardNum || isNaN(wardNum) || wardNum < 1 || wardNum > WARD_LIST.length) {
    WARD_NAME = '';
    return false;
  }
  WARD_NAME = WARD_LIST[parseInt(wardNum, 10)-1];
  return true;
}

function loadWardApplications(){
  const apps = JSON.parse(localStorage.getItem('apps')||'[]').filter(a=>a.ward===WARD_NAME);
  const c = document.getElementById('ward-apps');
  if(apps.length===0){c.innerHTML='<div class="card small">No applications for this ward yet.</div>';return;}
  let html = '<table class="ward-apps-table"><thead><tr>' +
    '<th>ID</th><th>Name</th><th>Type</th><th>Institution</th><th>Parent/Guardian</th><th>Phone</th><th>DOB</th><th>Gender</th><th>Status</th><th>Actions</th>' +
    '</tr></thead><tbody>';
  apps.forEach(a=>{
    html += `<tr>
      <td>${a.id}</td>
      <td>${a.first} ${a.last}</td>
      <td>${a.type ? a.type.charAt(0).toUpperCase()+a.type.slice(1) : '-'}</td>
      <td>${a.institution || '-'}</td>
      <td>${a.parentname || '-'}</td>
      <td>${a.phone || a.parentphone || '-'}</td>
      <td>${a.dob || '-'}</td>
      <td>${a.gender || '-'}</td>
      <td>${a.status || 'Pending'}</td>
      <td><div class="ward-app-actions">
        <button class="ward-app-edit" onclick="editSecondary('${a.id}')">Edit</button>
        <button class="ward-app-remove" onclick="removeStudent('${a.id}')">Remove</button>
        <button class="ward-app-forward" onclick="forwardStudent('${a.id}')">Forward</button>
      </div></td>
    </tr>`;
  });
  html += '</tbody></table>';
  c.innerHTML = html;
}
function removeStudent(id) {
  if(!confirm('Are you sure you want to remove this student?')) return;
  let apps = JSON.parse(localStorage.getItem('apps')||'[]');
  apps = apps.filter(a=>a.id!==id);
  localStorage.setItem('apps', JSON.stringify(apps));
  loadWardApplications();
}

function forwardStudent(id) {
  let apps = JSON.parse(localStorage.getItem('apps')||'[]');
  const app = apps.find(a=>a.id===id);
  if(!app){alert('Not found');return;}
  app.status = 'Forwarded';
  localStorage.setItem('apps', JSON.stringify(apps));
  // Simulate sending to MP dashboard by storing in localStorage (demo)
  let mpApps = JSON.parse(localStorage.getItem('mpApps')||'[]');
  mpApps.push(app);
  localStorage.setItem('mpApps', JSON.stringify(mpApps));
  alert('Student forwarded to MP dashboard (demo).');
  loadWardApplications();
}
function editSecondary(id){
  const apps = JSON.parse(localStorage.getItem('apps')||'[]');
  const app = apps.find(a=>a.id===id);
  if(!app){alert('Not found');return;}
  const newName = prompt('Edit student first name', app.first);
  if(newName!==null){ app.first = newName; localStorage.setItem('apps', JSON.stringify(apps)); alert('Saved (demo)'); loadWardApplications();}
}

document.addEventListener('DOMContentLoaded',()=>{
  // Show login form if not logged in
  if (!setWardNameFromStorage()) {
    document.getElementById('ward-login-container').style.display = 'flex';
    document.getElementById('ward-dashboard-container').style.display = 'none';
    document.getElementById('ward-login-form').onsubmit = function(e) {
      e.preventDefault();
      const wardNum = document.getElementById('wardNum').value;
      if (!wardNum || isNaN(wardNum) || wardNum < 1 || wardNum > WARD_LIST.length) {
        alert('Invalid ward number. Please enter a valid number (1-'+WARD_LIST.length+').');
        return;
      }
      localStorage.setItem('wardNum', wardNum);
      location.reload();
    };
  } else {
    document.getElementById('ward-login-container').style.display = 'none';
    document.getElementById('ward-dashboard-container').style.display = 'block';
    const header = document.querySelector('.header-top .ward-name');
    if(header) header.textContent = WARD_NAME;
    loadWardApplications();
    const logoutBtn = document.getElementById('ward-logout');
    if(logoutBtn) {
      logoutBtn.onclick = function() {
        localStorage.removeItem('wardNum');
        location.reload();
      };
    }
  }
});
