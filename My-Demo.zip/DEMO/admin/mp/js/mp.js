
// mp.js - MP dashboard demo functions
function loadApplications(){
  const apps = JSON.parse(localStorage.getItem('apps')||'[]');
  const stats = document.getElementById('mp-stats');
  const table = document.getElementById('app-table');
  // Sort controls
  let selectedWard = localStorage.getItem('mpSortWard') || '';
  let selectedLevel = localStorage.getItem('mpSortLevel') || '';
    // List all wards explicitly
    const ALL_WARDS = [
      'Olopito Ward',
      'Olokurto Ward',
      'Enaibelibel Ward',
      'Topoti Ward',
      'Olorropil Ward',
      'Unspecified'
    ];
    let wardOptions = ALL_WARDS;
  let levelOptions = Array.from(new Set(apps.map(a=>a.type||'Unspecified'))).sort();
  // (removed duplicate sortHtml declaration)
    let sortHtml = `<form class="mp-sort-row" style="margin-bottom:18px;display:flex;gap:22px;align-items:center;background:#e3f0ff;padding:14px 22px;border-radius:12px;box-shadow:0 2px 10px rgba(11,99,214,0.07);">\n
      <label for="mpSortWard" style="color:#1976d2;font-weight:600;font-size:1.08em;">Sort by Ward:</label>\n
      <select id="mpSortWard" style="padding:7px 18px;border-radius:8px;border:1px solid #1976d2;background:#fff;color:#1976d2;font-weight:600;font-size:1em;box-shadow:0 1px 6px rgba(11,99,214,0.07);">\n
        <option value="">All Wards</option>\n
        ${wardOptions.map(w=>`<option value="${w}"${selectedWard===w?' selected':''}>${w}</option>`).join('')}\n
      </select>\n
      <label for="mpSortLevel" style="color:#388e3c;font-weight:600;font-size:1.08em;">Sort by Level:</label>\n
      <select id="mpSortLevel" style="padding:7px 18px;border-radius:8px;border:1px solid #388e3c;background:#fff;color:#388e3c;font-weight:600;font-size:1em;box-shadow:0 1px 6px rgba(56,142,60,0.07);">\n
        <option value="">All Levels</option>\n
        ${levelOptions.map(l=>`<option value="${l}"${selectedLevel===l?' selected':''}>${l.charAt(0).toUpperCase()+l.slice(1)}</option>`).join('')}\n
      </select>\n
    </form>`;
  stats.innerHTML = `<div class="card"><strong>Total Applications:</strong> ${apps.length}</div>` + sortHtml;
  // Filter and sort applications
  let filteredApps = apps.filter(a =>
    (selectedWard === '' || a.ward === selectedWard) &&
    (selectedLevel === '' || a.type === selectedLevel)
  );
  // Sort applications by ward
  const wards = {};
  filteredApps.forEach(a => {
    const ward = a.ward || 'Unspecified';
    if (!wards[ward]) wards[ward] = [];
    wards[ward].push(a);
  });
  let html = '<div class="card"><h3>Bursary Applications</h3>';
  Object.keys(wards).sort().forEach(ward => {
    html += `<h4 style="color:#0b63d6;margin-top:18px;">${ward}</h4>`;
    html += '<table class="app-table"><thead><tr>' +
      '<th>ID</th><th>Name</th><th>Type</th><th>Institution</th><th>Parent/Guardian</th><th>Phone</th><th>DOB</th><th>Gender</th><th>Status</th><th>Action</th>' +
      '</tr></thead><tbody>';
    wards[ward].forEach(a => {
      let status = a.status || 'pending';
      let colorClass = status === 'approved' ? 'status-approved' : status === 'rejected' ? 'status-rejected' : 'status-pending';
      html += `<tr style="border-top:1px solid #eee">
        <td>${a.id}</td>
        <td>${a.first} ${a.last}</td>
        <td>${a.type || '-'} </td>
        <td>${a.institution || '-'} </td>
        <td>${a.parentname || '-'} </td>
        <td>${a.phone || a.parentphone || '-'} </td>
        <td>${a.dob || '-'} </td>
        <td>${a.gender || '-'} </td>
        <td><span class="status-btn ${colorClass}">${status.charAt(0).toUpperCase()+status.slice(1)}</span></td>
        <td><div class="mp-app-actions">
          <button class="mp-approve-btn" onclick="approve('${a.id}')">Approve</button>
          <button class="mp-reject-btn" onclick="reject('${a.id}')">Reject</button>
        </div></td>
      </tr>`;
    });
    html += '</tbody></table>';
  });
  html += '</div>';
  table.innerHTML = html;
  // Add event listeners for sort controls
  setTimeout(()=>{
    const wardSel = document.getElementById('mpSortWard');
    const levelSel = document.getElementById('mpSortLevel');
    if(wardSel) wardSel.onchange = function(){
      localStorage.setItem('mpSortWard', wardSel.value);
      loadApplications();
    };
    if(levelSel) levelSel.onchange = function(){
      localStorage.setItem('mpSortLevel', levelSel.value);
      loadApplications();
    };
  }, 100);
}
function approve(id){
  let apps = JSON.parse(localStorage.getItem('apps')||'[]');
  apps = apps.map(a=> a.id===id?({...a,status:'approved'}):a);
  localStorage.setItem('apps', JSON.stringify(apps));
  alert('Application '+id+' approved (demo)');
  loadApplications();
}
function reject(id){
  let apps = JSON.parse(localStorage.getItem('apps')||'[]');
  apps = apps.map(a=> a.id===id?({...a,status:'rejected'}):a);
  localStorage.setItem('apps', JSON.stringify(apps));
  alert('Application '+id+' rejected (demo)');
  loadApplications();
}
function renderFGMReports() {
  const section = document.getElementById('fgm-reports-section');
  if (!section) return;
  const reports = JSON.parse(localStorage.getItem('fgmReports') || '[]');
  if (reports.length === 0) {
    section.innerHTML = '<div class="fgm-reports-card"><h3>FGM Reports</h3><p class="fgm-empty">No FGM reports submitted yet.</p></div>';
    return;
  }
  let html = '<div class="fgm-reports-card"><h3>FGM Reports</h3>';
  html += '<table class="fgm-table"><thead><tr><th>Name</th><th>Contact</th><th>Location</th><th>Details</th><th>Time</th><th>Reaction</th><th>Response</th></tr></thead><tbody>';
  reports.slice().reverse().forEach((r, idx) => {
    const reactionId = `fgm-reaction-${idx}`;
    const responseId = `fgm-response-${idx}`;
    html += `<tr>
      <td>${r.name}</td>
      <td>${r.contact}</td>
      <td>${r.location}</td>
      <td>${r.details}</td>
      <td>${new Date(r.timestamp).toLocaleString()}</td>
      <td>
        <select id="${reactionId}" style="padding:4px 10px;border-radius:6px;background:#e3f0ff;color:#1976d2;font-weight:600;">
          <option value="">Select Reaction</option>
          <option value="Investigating">Investigating</option>
          <option value="Contacting Authorities">Contacting Authorities</option>
          <option value="Providing Support">Providing Support</option>
          <option value="No Action">No Action</option>
        </select>
      </td>
      <td>
        <form onsubmit="saveFGMResponse(event, ${idx})">
          <input type="text" id="${responseId}" placeholder="Type response..." style="padding:4px 10px;border-radius:6px;width:120px;" />
          <button type="submit" style="background:#388e3c;color:#fff;border:none;border-radius:6px;padding:4px 12px;margin-left:6px;">Send</button>
        </form>
      </td>
    </tr>`;
  });
  html += '</tbody></table></div>';
  section.innerHTML = html;
}
// Save FGM response (demo: stores in localStorage)
function saveFGMResponse(e, idx) {
  e.preventDefault();
  const reports = JSON.parse(localStorage.getItem('fgmReports') || '[]');
  const responseInput = document.getElementById(`fgm-response-${idx}`);
  const reactionSelect = document.getElementById(`fgm-reaction-${idx}`);
  if (!responseInput || !reactionSelect) return;
  const response = responseInput.value.trim();
  const reaction = reactionSelect.value;
  if (!reaction && !response) {
    alert('Please select a reaction or enter a response.');
    return;
  }
  // Save to report (demo only)
  reports[reports.length-1-idx].reaction = reaction;
  reports[reports.length-1-idx].response = response;
  localStorage.setItem('fgmReports', JSON.stringify(reports));
  alert('Response saved (demo).');
  renderFGMReports();
}

document.addEventListener('DOMContentLoaded',()=>{
  // Dashboard button logic
  function showSection(section) {
    document.getElementById('bursary-section').style.display = section === 'bursary' ? '' : 'none';
    document.getElementById('projects-section').style.display = section === 'projects' ? '' : 'none';
    document.getElementById('fgm-section').style.display = section === 'fgm' ? '' : 'none';
  }

  // Render projects
  function renderProjects() {
    const container = document.getElementById('projects-section');
    if (!container) return;
    // Get projects and map status for dashboard
    let projects = JSON.parse(localStorage.getItem('projects') || '[]');
    projects = projects.map(p => ({
      ...p,
      name: p.title || p.name,
      description: p.desc || p.description,
      status: (p.status === 'ongoing') ? 'in progress' : (p.status || '').toLowerCase()
    }));
    if (!projects.length) {
      container.innerHTML = '<div class="projects-card"><h3>Projects</h3><p class="fgm-empty">No projects found.</p></div>';
      return;
    }
    // Sort by status: completed, in progress, stalled
    const statusOrder = ['completed', 'in progress', 'stalled'];
    let html = '<div class="projects-card"><h3>Projects</h3>';
    statusOrder.forEach(status => {
      const filtered = projects.filter(p => p.status === status);
      if (filtered.length) {
        let statusClass = status === 'completed' ? 'status-completed' : status === 'in progress' ? 'status-inprogress' : 'status-stalled';
        html += `<h4 style="color:#3a8ef6;margin-top:18px;">${status.charAt(0).toUpperCase()+status.slice(1)}</h4>`;
        html += '<table class="projects-table"><thead><tr><th>ID</th><th>Name</th><th>Ward</th><th>Status</th><th>Description</th></tr></thead><tbody>';
        filtered.forEach(p => {
          html += `<tr><td>${p.id}</td><td>${p.name}</td><td>${p.ward||''}</td><td><span class="${statusClass}">${status.charAt(0).toUpperCase()+status.slice(1)}</span></td><td>${p.description||''}</td></tr>`;
        });
        html += '</tbody></table>';
      }
    });
    html += '</div>';
    container.innerHTML = html;
  }

  // Button event listeners
  document.getElementById('btn-bursary').onclick = function() {
    showSection('bursary');
  };
  document.getElementById('btn-projects').onclick = function() {
    renderProjects();
    showSection('projects');
  };
  document.getElementById('btn-fgm').onclick = function() {
    renderFGMReports();
    showSection('fgm');
  };

  // Initial view
  showSection('bursary');
  loadApplications();
  renderProjects();
  renderFGMReports();
});
